<?php
// Heading
$_['heading_title']    = '佈景主題';

// Text
$_['text_success']     = '成功: 佈景主題設定已更新!';

// Column
$_['column_name']      = '佈景主題名稱';
$_['column_status']    = '狀態';
$_['column_action']    = '操作';

// Error
$_['error_permission'] = '警告: 您沒有權限編輯佈景主題!';
$_['error_extension']  = '警告: 擴充模組不存在!';
