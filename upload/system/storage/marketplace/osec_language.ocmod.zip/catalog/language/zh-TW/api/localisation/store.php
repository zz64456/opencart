<?php
// Text
$_['text_success'] = '成功: 商店別已變更!';

// Error
$_['error_store']  = '警告: 找不到商店!';