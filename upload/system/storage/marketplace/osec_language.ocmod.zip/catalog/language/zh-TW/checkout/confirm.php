<?php
// Text
$_['text_points']                = '紅利點數';
$_['text_subscription']          = '訂閱方案';
$_['text_subscription_trial']    = '%s every %d %s(s) for %d payment(s) then ';
$_['text_subscription_duration'] = '%s every %d %s(s) for %d payment(s)';
$_['text_subscription_cancel']   = '%s every %d %s(s) 直到取消訂閱';
$_['text_day']                   = '日';
$_['text_week']                  = '週';
$_['text_semi_month']            = '半月';
$_['text_month']                 = '月';
$_['text_year']                  = '年';

// Column
$_['column_name']                = '品名';
$_['column_model']               = '型號';
$_['column_quantity']            = '數量';
$_['column_price']               = '單價';
$_['column_total']               = '合計';