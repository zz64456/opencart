<?php
// Text
$_['text_subject'] = '重置安全碼嘗試';
$_['text_reset']   = '安全碼已輸入錯誤超過 3 次';
$_['text_link']    = '點擊下方的連結以設定安全碼:';
$_['text_ip']      = 'IP:';
$_['text_regards'] = 'Best Regards';