<?php
// Heading
$_['heading_title']    = '台灣正體中文';

// Text
$_['text_extension']   = '擴充模組';
$_['text_success']     = '成功: 台灣正體中文語系已更新!';
$_['text_edit']        = '編輯台灣正體中文';

// Entry
$_['entry_status']     = '狀態';

// Error
$_['error_permission'] = '警告: 您沒有權限編輯台灣正體中文!';
