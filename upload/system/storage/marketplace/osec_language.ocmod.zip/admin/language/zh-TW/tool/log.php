<?php
// Heading
$_['heading_title']    = '錯誤日誌';

// Text
$_['text_success']     = '成功: 錯誤日誌已清除！';
$_['text_list']        = '錯誤清單';

// Error
$_['error_permission'] = '警告: 您沒有權限清除錯誤日誌！';
$_['error_file']       = 'Warning: %s file could not be found!';
$_['error_size']       = 'Warning: 錯誤日誌檔案 %s is %s!';
$_['error_empty']      = 'Warning: 錯誤日誌檔案 %s is empty!';