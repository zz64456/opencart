<?php
// Text
$_['text_language'] = '語系';