<?php
// Text
$_['text_subject'] = '%s - 您的會員帳號已經被啟用！';
$_['text_welcome'] = '歡迎並感謝您加入 %s！';
$_['text_login']   = '您的會員帳號已建立，並已可以使用您的Email和密碼從以下網址登入到我們的網站:';
$_['text_service'] = '登入後，您將能夠使用服務包括檢視訂單記錄、和編輯您的帳號資料！';
$_['text_thanks']  = '謝謝';

// Button
$_['button_login'] = '登入';