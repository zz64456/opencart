<?php
// Heading 
$_['heading_title'] = '結帳';

// Text
$_['text_cart']     = '購物車';
