<?php
// Text
$_['text_subject']	= '%s - 商品評論';
$_['text_waiting']	= '你有一筆新的商品評論等待審核';
$_['text_product']	= '商品: %s';
$_['text_reviewer']	= '評論者: %s';
$_['text_rating']	= '評價: %s';
$_['text_review']	= '評論內容:';