<?php
// Heading
$_['heading_title']    = '擴充模組市集(Marketplace)';

// Text
$_['text_success']     = '成功: 擴充模組市集已更新!';
$_['text_list']        = '擴充模組清單';

// Column
$_['column_name']      = '擴充模組名稱';
$_['column_status']    = '狀態';
$_['column_action']    = '操作';

// Error
$_['error_permission'] = '警告: 您沒有權限使用擴充模組市集!';
$_['error_extension']  = '警告: 擴充模組不存在!';