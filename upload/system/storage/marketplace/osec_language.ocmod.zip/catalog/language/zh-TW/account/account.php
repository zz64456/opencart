<?php
// Heading
$_['heading_title']       = '我的帳號';

// Text
$_['text_account']        = '會員中心';
$_['text_my_account']     = '我的帳號';
$_['text_my_orders']      = '我的訂單';
$_['text_my_affiliate']   = '推薦帳號';
$_['text_my_newsletter']  = '我的訂閱';
$_['text_edit']           = '編輯帳號';
$_['text_password']       = '變更密碼';
$_['text_address']        = '常用地址';
$_['text_payment_method'] = '常用付款資料';
$_['text_wishlist']       = '追蹤清單';
$_['text_order']          = '我的訂單';
$_['text_subscription']   = '我的訂閱';
$_['text_download']       = '我的下載';
$_['text_reward']         = '紅利點數'; 
$_['text_return']         = '商品退換'; 
$_['text_transaction']    = '購物金'; 
$_['text_newsletter']     = '電子報';
$_['text_transactions']   = '購物金';
$_['text_affiliate_add']  = '申請推薦帳號';
$_['text_affiliate_edit'] = '編輯推薦帳號';
$_['text_tracking']       = '自訂推薦追蹤碼';