<?php
// Text
$_['text_subject']      = '%s - 訂單更新 %s';
$_['text_order_id']     = '訂單編號:';
$_['text_date_added']   = '訂單日期:';
$_['text_order_status'] = '您的訂單已經更新為以下的狀態:';
$_['text_comment']      = '訂單備註:';
$_['text_link']         = '需要檢視訂單，請點擊下面連結:';
$_['text_footer']       = '如果您有任何問題請回覆本郵件';