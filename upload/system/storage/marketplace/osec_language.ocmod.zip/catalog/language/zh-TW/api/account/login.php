<?php
// Text
$_['text_success']     = '成功: API Session 啟用成功！';

// Error
$_['error_permission'] = '警告: 您沒有權限使用此 API!';
$_['error_key']        = '警告: API Key 不正確!';
$_['error_ip']         = '警告: 您的 IP %s 並沒有被允許使用此 API!';