<?php
// Heading
$_['heading_title']    = '其他模組';

// Text
$_['text_success']     = '成功: 其他模組設定已更新!';
$_['text_list']        = '其他模組清單';

// Column
$_['column_name']      = '其他模組名稱';
$_['column_status']    = '狀態';
$_['column_action']    = '操作';

// Error
$_['error_permission'] = '警告: 您沒有權限編輯其他模組!';
$_['error_extension']  = '警告: 擴充模組不存在!';