<?php
// Heading
$_['heading_title']         = '付款方式';

// Text
$_['text_account']          = '我的帳號';
$_['text_payment_method']   = '付款方式';
$_['text_success']          = '付款方式已刪除';
$_['text_no_results']       = '目前沒有付款方式';

// Column
$_['column_payment_method'] = '付款方式';
$_['column_type']           = '種類';
$_['column_date_expire']    = '到期日';
$_['column_action']         = '管理';

// Error
$_['error_payment_method']  = '警告: 找不到付款方式!';
