<?php
/*
	$Project: Ka Extensions $
	$Author: karapuz team <support@ka-station.com> $

	$Version: 4.1.0.21 $ ($Revision: 206 $)
*/

$_['text_days']    = 'дни';
$_['text_hours']   = 'часы';
$_['text_minutes'] = 'минуты';
$_['text_seconds'] = 'секунды';