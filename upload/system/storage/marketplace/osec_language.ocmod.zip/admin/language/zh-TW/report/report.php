<?php
// Heading
$_['heading_title'] = '統計報表';

// Text
$_['text_success']  = '成功: 統計報表設定已更新!';
$_['text_type']     = '選擇統計報表種類';
$_['text_filter']   = '條件篩選';