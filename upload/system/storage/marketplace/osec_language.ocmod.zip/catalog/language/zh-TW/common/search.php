<?php
// Text
$_['text_search'] = '商品搜尋';