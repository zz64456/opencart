<?php
// Heading
$_['heading_title'] = '您要開啟的頁面不存在！';

// Text
$_['text_error']    = '您要開啟的頁面不存在！';