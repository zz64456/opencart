<?php
// Heading
$_['heading_title']    = '防範詐騙';

// Text
$_['text_success']     = '成功: 防範詐騙模組設定已更新!';
$_['text_list']        = '防範詐騙模組清單';

// Column
$_['column_name']      = '防範詐騙模組名稱';
$_['column_status']    = '狀態';
$_['column_action']    = '操作';

// Error
$_['error_permission'] = '警告: 您沒有權限編輯防範詐騙模組!';
$_['error_extension']  = '警告: 擴充模組不存在!';