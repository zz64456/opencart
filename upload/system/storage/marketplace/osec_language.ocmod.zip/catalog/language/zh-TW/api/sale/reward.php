<?php
// Text
$_['text_success']  = '成功: 紅利點數支付已套用!';
$_['text_remove']   = '成功: 紅利點數支付已移除!';

// Error
$_['error_reward']  = '警告: 請輸入要支付的紅利點數!';
$_['error_points']  = '警告: 您的紅利點數不足 %s 點!';
$_['error_maximum'] = '警告: 您最多能使用的紅利點數是 %s 點!';