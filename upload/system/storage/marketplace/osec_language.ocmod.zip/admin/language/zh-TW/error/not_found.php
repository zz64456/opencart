<?php
// Heading
$_['heading_title']  = '找不到頁面！';

// Text
$_['text_not_found'] = '抱歉！ 無法找到您所請求的頁面，請返回重試！';
