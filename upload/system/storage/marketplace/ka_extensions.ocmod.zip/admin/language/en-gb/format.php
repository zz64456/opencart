<?php
/*
	$Project: Ka Extensions $
	$Author: karapuz team <support@ka-station.com> $

	$Version: 4.1.0.21 $ ($Revision: 206 $)
*/

$_['text_days']    = 'days';
$_['text_hours']   = 'hours';
$_['text_minutes'] = 'minutes';
$_['text_seconds'] = 'seconds';