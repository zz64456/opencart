<?php
// Heading
$_['heading_title']    = 'Feeds 模組';

// Text
$_['text_success']     = '成功: Feeds 模組設定已更新!';
$_['text_list']        = 'Feeds 模組清單';

// Column
$_['column_name']      = 'Feed 模組名稱';
$_['column_status']    = '狀態';
$_['column_action']    = '操作';

// Error
$_['error_permission'] = '警告: 您沒有權限編輯 Feeds 模組!';
$_['error_extension']  = '警告: 擴充模組不存在!';