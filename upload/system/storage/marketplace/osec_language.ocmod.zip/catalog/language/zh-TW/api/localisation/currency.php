<?php
// Text
$_['text_success']   = '成功: 幣別已變更!';

// Error
$_['error_currency'] = '警告: 幣別代碼無效!';