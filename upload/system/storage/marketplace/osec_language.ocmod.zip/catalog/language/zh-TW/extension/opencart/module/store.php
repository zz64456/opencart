<?php
// Heading 
$_['heading_title'] = '選擇商店';

// Text
$_['text_default']  = '預設';
$_['text_store']    = '請選擇您要瀏覽的商店';