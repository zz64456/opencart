<?php
// Text
$_['text_price'] = '售價:';
$_['text_tax']   = '未稅:';