<?php
// Heading
$_['heading_title']    = '免運費';

// Text
$_['text_description'] = '免運費';