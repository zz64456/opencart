<?php
$_['error_language'] = '警告: 找不到語系檔案!';