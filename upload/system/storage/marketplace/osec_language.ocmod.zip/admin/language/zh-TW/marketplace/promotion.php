<?php
// Text
$_['text_recommended'] = '推薦模組';
$_['text_install']     = '安裝';
$_['text_uninstall']   = '解除安裝';
$_['text_delete']      = '移除';
