<?php
/*
	$Project: CSV Product Import $
	$Author: karapuz team <support@ka-station.com> $

	$Version: 6.0.0.2 $ ($Revision: 572 $)
*/

$_['CSV Product Import']             = 'CSV Product Import';
$_['Import Groups']                  = 'Import Groups';
$_['Import Replacements']            = 'Import Replacements';
$_['Import Skip Rules']              = 'Import Skip Rules';
$_['Import Price Rules']             = 'Import Price Rules';
$_['CSV Product Extra']              = 'CSV Product Extra';

$_['Next']                           = 'Next';
$_['stock status not found']         = 'stock status not found';