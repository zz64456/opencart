<?php
/*
	$Project: CSV Product Import $
	$Author: karapuz team <support@ka-station.com> $

	$Version: 6.0.0.2 $ ($Revision: 572 $)
*/
$_['<br/>It seems, the new exte...'] = '<br/>It seems, the new extension version was uploaded by overwriting an existing extension. 
		<br/><br/>the \'Import replacements\' table does not exist. Please re-activate the extension on 
		<a href="%ka_extensions_link%">the \'Ka-Extensions\' page</a>,
		by clicking on \'Uninstall\' and \'Install\' links sequentially.';
$_['Import Replacements List']       = 'Import Replacements List';
$_['This page helps to add auto...'] = 'This page helps to add automatic replacements to the <b>CSV Product Import</b> module. It might be helpful to replace some category paths or manufacturer names or default status values, which names do not match to any statuses in your store.<br /> 
<br />
Rules:<br />
- the value will be replaced on complete match. It is not supposed to replace a part of the text.<br />
- the value is replaced right after reading it from the file before any manipulations or comparisons with db.<br />';
$_['Old Value']                      = 'Old Value';
$_['New Value']                      = 'New Value';
$_['Import Group']                   = 'Import Group';

$_['Column Name'] = 'Column Name';
$_['Manage import groups'] = 'Manage import groups';
$_['Import Replacements'] = 'Import Replacements';
$_['No Group'] = 'No Group';