<?php
// Heading
$_['heading_title'] = '擴充模組';

// Text
$_['text_success']  = '成功: 擴充模組設定已更新!';
$_['text_list']     = '擴充模組清單';
$_['text_type']     = '請選擇擴充模組類別';
$_['text_filter']   = '篩選';