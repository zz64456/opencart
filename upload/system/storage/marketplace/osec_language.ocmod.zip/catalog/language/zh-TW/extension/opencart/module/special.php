<?php
// Heading 
$_['heading_title'] = '特價商品';