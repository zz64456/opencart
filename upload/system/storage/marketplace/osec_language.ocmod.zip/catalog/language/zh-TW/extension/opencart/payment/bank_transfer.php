<?php
// Heading
$_['heading_title']    = '銀行匯款/轉帳';

// Text
$_['text_instruction'] = '銀行匯款/轉帳說明';
$_['text_description'] = '請將訂單金額匯款或轉帳到以下銀行帳戶。';
$_['text_payment']     = '確認付款後我們將依訂單出貨給您。';