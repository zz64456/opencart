<?php
/*
	$Project$
	$Author$

	$Version$ ($Revision$)
*/

$_['txt_warning'] = 'Warning';
$_['txt_error']   = 'Error';
$_['txt_success'] = 'Success';
$_['txt_info']    = 'Info';

$_['txt_field_validation_error'] = 'Some data is not filled in. Please check the form fields: ';

$_['txt_operation_successful']  = 'Operation has completed successfully.';
$_['txt_operation_failed']      = 'Operation failed';

$_['error_warning']          = 'Warning: Please check the form carefully for errors!';
$_['error_permission']       = 'Warning: You do not have permission to modify the settings!';