<?php
// Text
$_['text_category']  = '分類';
$_['text_all']       = '全部顯示';