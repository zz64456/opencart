<?php
// Heading
$_['heading_title']    = '商店資訊頁面';

// Text
$_['text_extension']   = '擴充模組';
$_['text_success']     = '成功: 商店資訊頁面設定已更新！';
$_['text_edit']        = '編輯商店資訊頁面';

// Entry
$_['entry_status']     = '狀態';

// Error
$_['error_permission'] = '警告: 您沒有權限修改商店資訊頁面模組！';