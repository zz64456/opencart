<?php
// Heading
$_['heading_title']    = '網站導覽';
 
// Text
$_['text_special']     = '特價商品';
$_['text_account']     = '我的帳號';
$_['text_edit']        = '帳號資訊';
$_['text_password']    = '更新密碼';
$_['text_address']     = '常用地址';
$_['text_history']     = '我的訂單';
$_['text_download']    = '我的下載';
$_['text_cart']        = '購物車';
$_['text_checkout']    = '結帳';
$_['text_search']      = '搜尋';
$_['text_information'] = '商店資訊';
$_['text_contact']     = '聯絡我們';