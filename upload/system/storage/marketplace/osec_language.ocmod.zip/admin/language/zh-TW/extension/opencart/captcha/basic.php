<?php
// Heading
$_['heading_title']    = '基本驗證碼';

// Text
$_['text_extension']   = '擴充功能';
$_['text_success']	   = '成功: 基本驗證碼設定已更新!';
$_['text_edit']        = '編輯基本驗證碼';

// Entry
$_['entry_status']     = '狀態';

// Error
$_['error_permission'] = '警告: 您沒有權限修改基本驗證碼!';