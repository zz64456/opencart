<?php
/*
	$Project: CSV Product Import $
	$Author: karapuz team <support@ka-station.com> $

	$Version: 6.0.0.2 $ ($Revision: 572 $)
*/

$_['CSV Product Import']  = 'CSV импорт продуктов';
$_['Import Groups']       = 'Группы импорта';
$_['Import Replacements'] = 'Замены';
$_['Import Skip Rules']   = 'Правила пропусков';
$_['Import Price Rules']  = 'Правила цен';
$_['CSV Product Extra']   = 'CSV Дополнения';