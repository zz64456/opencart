<?php
// Heading
$_['heading_title'] 	= '全球地圖';

// Text
$_['text_extension']   	= '擴充功能';
$_['text_success']     	= '成功: 資訊總覽全球地圖設定已更新!';
$_['text_edit']        	= '編輯資訊總覽全球地圖';
$_['text_order']    	= '訂單';
$_['text_sale']     	= '銷售';

// Entry
$_['entry_status']     	= '狀態';
$_['entry_sort_order'] 	= '排序';
$_['entry_width']		= '寬度';

// Error
$_['error_permission'] 	= '警告: 您沒有權限修改資訊總覽全球地圖!';