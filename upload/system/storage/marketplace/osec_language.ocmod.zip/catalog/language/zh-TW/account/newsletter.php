<?php
// Heading 
$_['heading_title']    = '訂閱電子報';

// Text
$_['text_account']     = '我的帳號';
$_['text_newsletter']  = '電子報';
$_['text_success']     = '成功: 電子報訂閱已更新！';

// Entry
$_['entry_newsletter'] = '訂閱';