<?php
// Heading
$_['heading_title']    = 'European Central Bank Currency Converter';

// Text
$_['text_extension']   = '擴充模組';
$_['text_success']     = '成功: European Central Bank Currency Converter 模組已更新!';
$_['text_edit']        = '編輯 European Central Bank 模組';
$_['text_support']     = 'This extension requires at EUR currency to be available currency option.';

// Entry
$_['entry_status']     = '狀態';

// Error
$_['error_permission'] = '警告: 您沒有權限編輯 European Central Bank Currency Converter 模組!';