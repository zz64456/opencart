<?php
// Heading
$_['heading_title']    = '按件計費';

// Text
$_['text_description'] = '按件數計算運費';