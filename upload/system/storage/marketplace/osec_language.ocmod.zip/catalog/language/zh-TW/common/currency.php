<?php
// Text
$_['text_currency'] = '幣別';