<?php
/*
	$Project: CSV Product Import $
	$Author: karapuz team <support@ka-station.com> $

	$Version: 6.0.0.2 $ ($Revision: 572 $)
*/

$_['txt_list_page_title']           = 'Import Group';
$_['txt_form_page_title']           = 'Import Group';

$_['txt_title_name']                 = 'Name';

$_['On this page the administra...'] = 'On this page the administrator can manage import groups. They are used to arrange other import rules by separate groups.
			On the import page, the administrator can select which group should be applied to each particular file import.';
			
$_['Name is empty'] = 'Name is empty';