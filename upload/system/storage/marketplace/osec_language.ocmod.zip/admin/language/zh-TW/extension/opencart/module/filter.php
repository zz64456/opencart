<?php
// Heading
$_['heading_title']    = '商品特性'; 

// Text
$_['text_extension']   = '擴充模組';
$_['text_success']     = '成功: 商品特性模組設定已更新！';
$_['text_edit']        = '編輯商品特性模組';

// Entry
$_['entry_status']     = '狀態';

// Error
$_['error_permission'] = '警告: 您沒有修改商品特性模組的權限！';