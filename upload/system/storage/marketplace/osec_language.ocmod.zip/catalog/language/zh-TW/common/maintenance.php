<?php
// Heading
$_['heading_title']    = '網站維護';

// Text
$_['text_maintenance'] = '網站維護中';
$_['text_message']     = '<h1 style="text-align:center;">現在我們正在進行網站維護，<br/>請稍後再瀏覽本站。</h1>';
