<?php
// Text
$_['text_wishlist'] 	 = '追蹤清單(%s)';
$_['text_shopping_cart'] = '購物車';
$_['text_account']  	 = '會員中心';
$_['text_register']      = '會員註冊';
$_['text_login']         = '會員登入';
$_['text_order']         = '我的訂單';
$_['text_transaction']   = '購物金';
$_['text_download']      = '我的下載';
$_['text_logout']        = '會員登出';
$_['text_checkout'] 	 = '結帳';