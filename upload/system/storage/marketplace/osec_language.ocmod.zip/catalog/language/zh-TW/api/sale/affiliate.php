<?php
// Text
$_['text_success']    = '成功: 推薦獎金將被套用在此訂單!';
$_['text_remove']     = '成功: 推薦獎金已被移除!';

// Error
$_['error_affiliate'] = '警告: 找不到推薦資料!';