<?php
// Text
$_['text_success'] = '成功: 折價券折扣已套用！';
$_['text_remove']  = '成功: 折價券折扣已移除!';

// Error
$_['error_coupon'] = '警告: 折價券無效，過期或已超過使用限制！';