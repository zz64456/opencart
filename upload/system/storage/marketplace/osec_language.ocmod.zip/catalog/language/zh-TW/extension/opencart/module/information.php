<?php
// Heading 
$_['heading_title'] = '商店資訊';

// Text
$_['text_contact']  = '聯絡我們';
$_['text_sitemap']  = '網站導覽';