<?php
// Text
$_['text_success']    = '感謝您讓我們知道您的選擇!';
$_['text_cookie']     = '本網站使用 cookies 儲存資料，請點擊閱讀 <a href="%s" class="alert-link modal-link">詳細內容</a>。';

// Button
$_['button_agree']    = '同意!';
$_['button_disagree'] = '不同意!';