<?php
// Heading
$_['heading_title']    = '語系模組';

// Text
$_['text_success']     = '成功: 語系模組已更新!';
$_['text_list']        = '語系清單';

// Column
$_['column_name']      = '語系名稱';
$_['column_status']    = '狀態';
$_['column_action']    = '操作';

// Error
$_['error_permission'] = '警告: 您沒有權限編輯語系模組!';
$_['error_extension']  = '警告: 語系模組不存在!';