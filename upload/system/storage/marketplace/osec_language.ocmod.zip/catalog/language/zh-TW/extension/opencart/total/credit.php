<?php
// Text
$_['text_credit']   = '購物金';
$_['text_order_id'] = '訂單編號: #%s';