<?php
/*
	$Project$
	$Author$

	$Version$ ($Revision$)
*/

$_['text_success'] = 'The settings have been saved successfully.';

$_['error_warning']          = 'Warning: Please check the form carefully for errors!';
$_['error_permission']       = 'Warning: You do not have permission to modify the settings!';