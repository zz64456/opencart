<?php
// Heading 
$_['heading_title']     = '會員中心';

// Text
$_['text_register']     = '會員註冊';
$_['text_login']        = '會員登入';
$_['text_logout']       = '會員登出';
$_['text_forgotten']    = '忘記密碼';
$_['text_account']      = '我的帳號';
$_['text_edit']         = '編輯帳號';
$_['text_password']     = '變更密碼';
$_['text_address']      = '常用地址';
$_['text_wishlist']     = '追蹤清單';
$_['text_order']        = '我的訂單';
$_['text_download']     = '我的下載';
$_['text_reward']       = '我的點數';
$_['text_return']       = '商品退換';
$_['text_transaction']  = '購物金';
$_['text_newsletter']   = '訂閱電子報';
$_['text_subscription'] = '我的訂閱';