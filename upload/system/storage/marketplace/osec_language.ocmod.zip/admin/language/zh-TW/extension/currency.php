<?php
// Heading
$_['heading_title']    = '幣別匯率';

// Text
$_['text_success']     = '成功: 幣別匯率模組設定已更新!';
$_['text_list']        = '幣別匯率模組清單';

// Column
$_['column_name']      = '幣別匯率模組名稱';
$_['column_status']    = '狀態';
$_['column_action']    = '操作';

// Error
$_['error_permission'] = '警告: 您沒有權限編輯幣別匯率模組!';
$_['error_extension']  = '警告: 擴充模組不存在!';