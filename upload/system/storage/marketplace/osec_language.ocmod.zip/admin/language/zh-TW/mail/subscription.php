<?php
// Text
$_['text_subject']             = '%s - 訂閱';
$_['text_subscription_id']     = '訂閱 ID';
$_['text_date_added']          = '訂閱日期:';
$_['text_subscription_status'] = '您的訂閱已被變更為下面的狀態:';
$_['text_comment']             = '您的訂閱說明:';
$_['text_payment_method']      = '付款方式';
$_['text_payment_code']        = '付款方式代碼';
$_['text_footer']              = '若有任何問題請回覆此信件';
