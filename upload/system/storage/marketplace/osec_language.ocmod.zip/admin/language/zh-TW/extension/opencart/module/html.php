<?php
// Heading
$_['heading_title']     = 'HTML 內容';

// Text
$_['text_extension']    = '擴充模組';
$_['text_success']      = '成功: HTML 內容模組設定已更新！';
$_['text_edit']         = '編輯 HTML 內容模組';

// Entry
$_['entry_name']        = '模組名稱';
$_['entry_title']       = '標題';
$_['entry_description'] = '內容';
$_['entry_status']      = '狀態';

// Error
$_['error_permission']  = '警告: 您沒有權限修改 HTML 內容模組！';
$_['error_name']        = '模組名稱必須是 3 到 64 個字 !';