<?php
// Heading
$_['heading_title'] = '資訊總覽';