<?php
// Text
$_['text_subject']  = '%s - 推薦獎金';
$_['text_received'] = '恭喜您! 您收到一筆來自 %s 的推薦獎金';
$_['text_amount']   = '您已收到:';
$_['text_total']    = '您目前的推薦獎金是:';