<?php
// Heading 
$_['heading_title']      = '購物金';

// Column
$_['column_date_added']  = '新增日期';
$_['column_description'] = '說明';
$_['column_amount']      = '總計 (%s)';

// Text
$_['text_account']       = '我的帳號';
$_['text_transaction']   = '購物金';
$_['text_total']         = '購物金餘額 :';
$_['text_no_results']    = '您目前沒有任何購物金！';