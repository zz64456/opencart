<?php
/*
	$Project$
	$Author$

	$Version$ ($Revision$)
*/

$_['CSV Product Import']             = 'CSV Импорт товаров';
$_['Import Groups']                  = 'Группы импорта';
$_['Import Replacements']            = 'Замены';
$_['Import Skip Rules']              = 'Правила пропусков';
$_['Import Price Rules']             = 'Правила цен';
$_['CSV Product Extra']              = 'CSV Дополнения';

$_['Next'] = 'Далее';
$_['stock status not found'] = 'Не найден статус наличия';
