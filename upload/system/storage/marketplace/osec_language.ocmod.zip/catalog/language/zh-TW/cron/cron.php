<?php
// Text
$_['text_success']     = '成功: %s 工作排程已執行!';

// Error
$_['error_permission'] = '警告: 您沒有權限更動工作排程!';