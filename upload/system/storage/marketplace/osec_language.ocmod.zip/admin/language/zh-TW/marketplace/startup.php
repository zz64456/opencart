<?php
// Heading
$_['heading_title']     = '啟動模組';

// Text
$_['text_success']      = '成功: 啟動模組已更新!';
$_['text_list']         = '啟動模組清單';

// Column
$_['column_code']       = '啟動碼';
$_['column_sort_order'] = '排序';
$_['column_action']     = '操作';

// Error
$_['error_permission']  = '警告: 您沒有權限編輯啟動模組!';
