<?php
// Heading
$_['heading_title']          = 'OpenCart';

// Text
$_['text_notification']      = '訊息通知';
$_['text_notification_all']  = '顯示全部';
$_['text_notification_none'] = '目前沒有任何訊息通知';
$_['text_profile']           = '帳號資料';
$_['text_store']             = '網站';
$_['text_help']              = '協助';
$_['text_homepage']          = '首頁';
$_['text_support']           = '支援論壇';
$_['text_documentation']     = '說明文件';
$_['text_logout']            = '登出';