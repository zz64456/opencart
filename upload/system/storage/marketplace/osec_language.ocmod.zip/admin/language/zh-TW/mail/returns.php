<?php
// Text
$_['text_subject']       = '%s - 退換狀態更新 %s';
$_['text_return_id']     = '退換編號(ID):';
$_['text_date_added']    = '退換日期:';
$_['text_return_status'] = '您的商品退換已更新為以下狀態:';
$_['text_comment']       = '您的商品退換備註:';
$_['text_footer']        = '如果您有任何問題請回覆此 Email。';
