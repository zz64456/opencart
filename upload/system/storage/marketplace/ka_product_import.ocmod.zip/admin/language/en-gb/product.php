<?php
/*
	$Project: CSV Product Import $
	$Author: karapuz team <support@ka-station.com> $

	$Version: 6.0.0.2 $ ($Revision: 572 $)
*/

$_['txt_skip_import']                = 'Skip Import';
$_['help_skip_import']               = "The field allows to exclude the product from 'CSV Product Import' operations. No product data will be updated during the import procedure.";