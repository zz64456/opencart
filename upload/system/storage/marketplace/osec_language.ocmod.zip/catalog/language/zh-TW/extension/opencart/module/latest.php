<?php
// Heading
$_['heading_title'] = '最新商品';