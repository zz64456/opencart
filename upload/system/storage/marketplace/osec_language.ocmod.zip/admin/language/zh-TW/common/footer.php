<?php
// Text
$_['text_footer']  = '<a href="https://www.opencart.com">OpenCart</a> & <a href="https://www.osec.tw">OSEC.tw</a> &copy; ' . date('Y') . ' All Rights Reserved.';
$_['text_version'] = '版本 %s';