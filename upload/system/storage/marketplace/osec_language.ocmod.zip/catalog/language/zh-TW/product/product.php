<?php
// Text
$_['text_search']                = '搜尋';
$_['text_brand']                 = '商品品牌:';
$_['text_manufacturer']          = '品牌:';
$_['text_model']                 = '商品型號:';
$_['text_reward']                = '紅利點數:'; 
$_['text_points']                = '使用點數購買:';
$_['text_stock']                 = '庫存狀態:';
$_['text_instock']               = '有現貨';
$_['text_tax']                   = '未稅:'; 
$_['text_discount']              = ' 件(含)以上';
$_['text_option']                = '款式及尺寸:';
$_['text_minimum']               = '本商品的最低購買數量為 %s 件';
$_['text_reviews']               = '%s 筆商品評論'; 
$_['text_write']                 = '如果您對本商品有任何問題，請在此留下您的意見和建議！';
$_['text_login']                 = '請 <a href="%s">登入</a> 或 <a href="%s">註冊</a> 後檢視商品評論！';
$_['text_related']               = '相關商品';
$_['text_tags']                  = '標籤:';
$_['text_error']                 = '此商品不存在！';
$_['text_subscription']          = '定期付款方式';
$_['text_subscription_trial']    = '%s 每 %d %s 給 %d 付款後';
$_['text_subscription_duration'] = '每期付款 %s, 每 %d 個 %s 一期，共 %d 期';
$_['text_subscription_cancel']   = '%s 每 %d %s 直到取消';
$_['text_day']                   = '天';
$_['text_week']                  = '周';
$_['text_semi_month']            = '半月';
$_['text_month']                 = '月';
$_['text_year']                  = '年';

// Entry
$_['entry_qty']                  = '數量';
$_['entry_rating']               = '評價';

// Tabs
$_['tab_description']            = '商品描述';
$_['tab_attribute']              = '商品屬性';
$_['tab_review']                 = '商品評論 (已有 %s 筆商品評論)';
