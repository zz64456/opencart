<?php
// Text
$_['text_captcha']  = '驗證碼';

// Entry
$_['entry_captcha'] = '在下面的文字框中輸入驗證碼';

// Error
$_['error_captcha'] = '您輸入的驗證碼有誤!';