<?php
// Text
$_['text_subject'] = '%s - 您的推薦會員帳號已被拒絕！';
$_['text_welcome'] = '歡迎並感謝您加入 %s！';
$_['text_denied']  = '很遺憾您的申請被拒絕了，若需要更進一步資訊請聯絡網站管理員:';
$_['text_thanks']  = '謝謝';