<?php
// Heading
$_['heading_title']        = '貨到付款';

// Error
$_['error_order_id']       = '訂單資料不存在!';
$_['error_payment_method'] = '付款方式不正確!';