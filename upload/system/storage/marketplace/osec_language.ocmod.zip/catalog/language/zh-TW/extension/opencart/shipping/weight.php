<?php
// Heading
$_['heading_title'] = '按重量計費';

// Text
$_['text_weight']   = '重量:';