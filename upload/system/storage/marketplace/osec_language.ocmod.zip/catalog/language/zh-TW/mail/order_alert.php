<?php
// Text
$_['text_subject']      = '%s - 訂單編號 %s';
$_['text_received']     = '您有一筆新訂單';
$_['text_order_id']     = '訂單編號:';
$_['text_date_added']   = '訂單日期:';
$_['text_order_status'] = '訂單狀態:';
$_['text_product']      = '商品';
$_['text_total']        = '總計';
$_['text_comment']      = '訂單備註:';