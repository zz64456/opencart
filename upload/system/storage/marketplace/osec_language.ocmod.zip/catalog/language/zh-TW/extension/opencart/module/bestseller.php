<?php
// Heading 
$_['heading_title'] = '熱賣商品';