<?php
// Heading
$_['heading_title']    = '驗證碼';

// Text
$_['text_success']     = '成功: 驗證碼模組設定已更新!';
$_['text_list']        = '驗證碼模組清單';

// Column
$_['column_name']      = '驗證碼模組名稱';
$_['column_status']    = '狀態';
$_['column_action']    = '操作';

// Error
$_['error_permission'] = '警告: 您沒有權限編輯驗證碼模組!';
$_['error_extension']  = '警告: 擴充模組不存在!';