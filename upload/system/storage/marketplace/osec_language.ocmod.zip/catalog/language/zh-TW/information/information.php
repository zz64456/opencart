<?php
// Text
$_['text_error'] = '找不到資訊頁面！';