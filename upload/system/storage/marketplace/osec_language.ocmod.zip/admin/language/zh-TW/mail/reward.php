<?php
// Text
$_['text_subject']  = '%s - 紅利點數';
$_['text_received'] = '您獲得了 %s 點的紅利點數!';
$_['text_total']    = '您目前累計的紅利點數為 %s 點';