<?php
// Text
$_['text_subject'] = '安全驗證';
$_['text_code']    = '您必須為後端管理設定安全碼';
$_['text_ip']      = 'IP:';
$_['text_regards'] = 'Best Regards';