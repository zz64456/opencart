<?php
// Text
$_['text_success']           = '成功: 運送方式已設定!';

// Error
$_['error_shipping_address'] = '警告: 必須有運送地址!';
$_['error_shipping_method']  = '警告: 必須有運送方式!';
$_['error_no_shipping']      = '警告: 沒有有效的運送方式!';
$_['error_shipping']         = '警告: 沒有需要運送的產品';