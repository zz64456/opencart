<?php
// Text
$_['text_subject']  = '%s - 請求密碼重設';
$_['text_greeting'] = '%s 管理員已要求一組新的密碼.';
$_['text_change']   = '要重設密碼請點擊下方連結:';
$_['text_ip']       = '要求重設密碼的 IP: %s';