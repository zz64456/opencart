<?php
// Text
$_['text_upload']     = '檔案已經成功上傳！';

// Error
$_['error_filename']  = '檔案名稱必須是 3 到 64 個字！';
$_['error_file_type'] = '無效的檔案類型！';
$_['error_upload']    = '必須上傳檔案！';