<?php
// Heading
$_['heading_title']    = '購物金';

// Text
$_['text_extension']   = '擴充模組';
$_['text_success']     = '成功: 購物金模組設定已更新！';
$_['text_edit']        = '編輯購物金模組';

// Entry
$_['entry_status']     = '狀態';
$_['entry_sort_order'] = '排序';

// Error
$_['error_permission'] = '警告: 您沒有權限修改購物金模組！';