<?php
// Heading
$_['heading_title']    = '門市取貨';

// Text
$_['text_description'] = '到門市取貨';