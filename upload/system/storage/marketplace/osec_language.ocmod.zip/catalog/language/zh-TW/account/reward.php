<?php
// Heading 
$_['heading_title']      = '紅利點數';

// Column
$_['column_date_added']  = '新增日期';
$_['column_description'] = '說明';
$_['column_points']      = '紅利點數';

// Text
$_['text_account']       = '我的帳號';
$_['text_reward']        = '紅利點數';
$_['text_total']         = '累計的紅利點數：';
$_['text_no_results']    = '您目前還沒有任何紅利點數！';
