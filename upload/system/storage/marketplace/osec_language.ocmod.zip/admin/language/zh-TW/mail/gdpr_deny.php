<?php
// Text
$_['text_subject']   = '%s - GDPR request denied!';
$_['text_export']    = 'Account Export Data Request';
$_['text_remove']    = 'Account Deletion Request';
$_['text_hello']     = 'Hello <strong>%s</strong>,';
$_['text_user']      = 'User';
$_['text_contact']   = 'Unfortunately your request has been denied. For more information you can contact the store here:';
$_['text_thanks']    = 'Thanks,';

// Button
$_['button_contact'] = 'Contact Us';