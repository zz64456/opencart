<?php
// Text
$_['text_success']         = '會員資料已更新';

// Error
$_['error_customer']       = '您必須選擇一個會員!';
$_['error_customer_group'] = '會員等級似乎無效!';
$_['error_firstname']      = '名字必須是 1 到 32 個字！';
$_['error_lastname']       = '姓氏必須是 1 到 32 個字！';
$_['error_email']          = 'Email 格式不正確！';
$_['error_telephone']      = '聯絡電話必須是 3 到 32 個字！';
$_['error_custom_field']   = '%s 必須填寫！';
$_['error_regex']          = '%s 不是一個有效的值!';
