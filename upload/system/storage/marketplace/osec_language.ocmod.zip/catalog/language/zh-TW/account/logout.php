<?php
// Heading 
$_['heading_title'] = '帳號登出';

// Text
$_['text_message']  = '<p>您已登出了您的帳號，可以安全離開電腦了。</p>';
$_['text_account']  = '我的帳號';
$_['text_logout']   = '登出';