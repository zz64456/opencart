<?php
// Text
$_['text_subject']  = '%s - 會員要求新密碼';
$_['text_greeting'] = '我們從 %s 收到您請求新的密碼，建議您在使用新密碼登入後立即變更此密碼，並妥善保管...';
$_['text_change']   = '請點擊下方連結以重設您的新密碼:';
$_['text_ip']       = '請求使用此功能的 IP 是:';

// Button
$_['button_reset']  = '重設新密碼';
