<?php
// Heading
$_['heading_title']    = '總訂單數';

// Text
$_['text_extension']   = '擴充功能';
$_['text_success']     = '成功: 資訊總覽的總訂單數設定已更新!';
$_['text_edit']        = '編輯資訊總覽的總訂單數';
$_['text_view']        = '檢視明細...';

// Entry
$_['entry_status']     = '狀態';
$_['entry_sort_order'] = '排序';
$_['entry_width']      = '寬度';

// Error
$_['error_permission'] = '警告: 您沒有權限修改資訊總覽的總訂單數!';